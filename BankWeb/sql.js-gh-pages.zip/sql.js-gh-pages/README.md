# SQLite compiled to JavaScript

## The sql.js project has moved to https://github.com/sql-js/sql.js
