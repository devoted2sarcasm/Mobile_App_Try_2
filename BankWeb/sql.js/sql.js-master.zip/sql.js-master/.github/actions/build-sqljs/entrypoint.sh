#!/bin/bash

set -e

cd /github/workspace/
npm run rebuild
