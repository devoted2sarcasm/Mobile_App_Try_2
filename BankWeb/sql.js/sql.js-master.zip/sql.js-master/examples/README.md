
To show these examples locally, first run:
    ./start_local_server.py

Then, open http://localhost:8081/index.html in a local browser.

