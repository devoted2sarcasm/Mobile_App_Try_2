//
//  ViewController.swift
//  Banking_FTW
//
//  Created by user241217 on 7/25/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

